package com.example.tarjoman

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.MultipartBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val pickVideo = 1001
    private var selectedUri: Uri? = null
    // بعد از راه‌اندازی سرور، نشانی آن را اینجا قرار بده.
    private val serverUrl = "http://10.0.2.2:8000/subtitle"
    private lateinit var fileName: TextView
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var processButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fileName = findViewById(R.id.fileName)
        statusText = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        processButton = findViewById(R.id.processButton)

        findViewById<Button>(R.id.chooseButton).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(intent, pickVideo)
        }
        processButton.setOnClickListener { uploadAndProcess() }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            selectedUri?.let {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                fileName.text = getDisplayName(it)
                processButton.isEnabled = true
                statusText.text = "فیلم انتخاب شد. برای ساخت زیرنویس آماده‌ای."
            }
        }
    }

    private fun getDisplayName(uri: Uri): String {
        var name = "video.mp4"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) name = c.getString(i)
        }
        return name
    }

    private fun uploadAndProcess() {
        val uri = selectedUri ?: return
        progress.visibility = View.VISIBLE
        processButton.isEnabled = false
        statusText.text = "در حال ارسال فیلم و ساخت زیرنویس... لطفاً صبر کن."
        Thread {
            try {
                val temp = File(cacheDir, "upload_video")
                contentResolver.openInputStream(uri).use { input ->
                    FileOutputStream(temp).use { output -> input!!.copyTo(output) }
                }
                val client = OkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.MINUTES)
                    .writeTimeout(30, TimeUnit.MINUTES).build()
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("file", getDisplayName(uri),
                        temp.asRequestBody("application/octet-stream".toMediaType())).build()
                val request = Request.Builder().url(serverUrl).post(body).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("خطای سرور: ${response.code} ${response.body?.string()}")
                    val bytes = response.body?.bytes() ?: throw IOException("فایل خروجی دریافت نشد.")
                    val outputFile = File(getExternalFilesDir(null), "Tarjoman_${System.currentTimeMillis()}.mp4")
                    outputFile.writeBytes(bytes)
                    runOnUiThread {
                        progress.visibility = View.GONE
                        processButton.isEnabled = true
                        statusText.text = "تمام شد! فایل در پوشه Android/data/com.example.tarjoman/files ذخیره شد."
                    }
                }
                temp.delete()
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    processButton.isEnabled = true
                    statusText.text = "مشکل: ${e.message}\nآدرس سرور و اتصال اینترنت را بررسی کن."
                }
            }
        }.start()
    }
}
