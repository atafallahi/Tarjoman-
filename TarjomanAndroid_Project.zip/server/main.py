import os, tempfile, subprocess
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import Response
from openai import OpenAI

app = FastAPI(title="Tarjoman subtitle server")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def srt_time(seconds: float) -> str:
    ms = int(max(0, seconds) * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

@app.post("/subtitle")
async def subtitle(file: UploadFile = File(...)):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(500, "OPENAI_API_KEY روی سرور تنظیم نشده است.")
    suffix = Path(file.filename or "video.mp4").suffix or ".mp4"
    with tempfile.TemporaryDirectory() as td:
        source = Path(td) / f"input{suffix}"
        audio = Path(td) / "audio.mp3"
        srt = Path(td) / "persian.srt"
        output = Path(td) / "output.mp4"
        source.write_bytes(await file.read())

        # استخراج صدای فیلم؛ FFmpeg باید روی سرور نصب باشد.
        p = subprocess.run(["ffmpeg", "-y", "-i", str(source), "-vn", "-ac", "1",
                            "-ar", "16000", "-b:a", "64k", str(audio)],
                           capture_output=True)
        if p.returncode:
            raise HTTPException(400, "خواندن صدای فیلم ناموفق بود؛ فرمت ویدئو را بررسی کنید.")

        with audio.open("rb") as af:
            transcript = client.audio.transcriptions.create(
                model="whisper-1", file=af, response_format="verbose_json"
            )

        lines = []
        for i, seg in enumerate(transcript.segments or [], start=1):
            original = (seg.get("text") if isinstance(seg, dict) else seg.text).strip()
            start = seg.get("start") if isinstance(seg, dict) else seg.start
            end = seg.get("end") if isinstance(seg, dict) else seg.end
            if not original:
                continue
            translated = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Translate the following spoken English into natural, concise Persian for movie subtitles. Return only the Persian translation."},
                    {"role": "user", "content": original}
                ],
                temperature=0.2
            ).choices[0].message.content.strip()
            lines.extend([str(i), f"{srt_time(start)} --> {srt_time(end)}", translated, ""])

        srt.write_text("\n".join(lines), encoding="utf-8-sig")
        # فونت فارسی روی سرور باید نصب باشد؛ مسیر فونت را در صورت نیاز عوض کنید.
        escaped_srt = str(srt).replace("\\", "/").replace(":", "\\:")
        vf = f"subtitles='{escaped_srt}':charenc=UTF-8"
        p = subprocess.run(["ffmpeg", "-y", "-i", str(source), "-vf", vf,
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                            "-c:a", "copy", "-movflags", "+faststart", str(output)],
                           capture_output=True)
        if p.returncode:
            raise HTTPException(500, "چسباندن زیرنویس ناموفق بود. FFmpeg و پشتیبانی libass را بررسی کنید.")
        # Read bytes before TemporaryDirectory is cleaned up.
        return Response(
            content=output.read_bytes(),
            media_type="video/mp4",
            headers={"Content-Disposition": 'attachment; filename="Tarjoman_Persian_Subtitles.mp4"'}
        )
